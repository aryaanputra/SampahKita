# SampahKita Brand Kit

Paket aset identitas visual untuk aplikasi bank sampah digital SampahKita.

## Isi paket
- `assets/logo/`: logo horizontal, simbol, dan versi putih (SVG).
- `assets/icons/`: favicon dan app icon (SVG).
- `tokens/colors.json`: palet warna dan fungsi penggunaan.
- `tokens/sampahkita.css`: CSS custom properties dan contoh gaya dasar.
- `guidelines/brand-guidelines.md`: panduan logo, warna, tipografi, dan UI.
- `guidelines/brand-board.svg`: papan ringkas identitas visual.

## Cara pakai
1. Salin folder `assets/` ke direktori public/assets frontend.
2. Gunakan `sampahkita_horizontal.svg` untuk header/sidebar.
3. Pasang favicon melalui: `<link rel="icon" type="image/svg+xml" href="/assets/icons/favicon.svg">`
4. Impor `tokens/sampahkita.css` ke stylesheet utama atau salin token yang diperlukan.
5. Gunakan `colors.json` sebagai referensi token warna.

## Arah identitas
Konsep Home & Bank: rumah, unsur bank, dan daun; palet Forest Green, Leaf Green, Lime Green, dan Mint.
