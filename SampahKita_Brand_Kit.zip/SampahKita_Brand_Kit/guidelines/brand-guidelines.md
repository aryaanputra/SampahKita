# Brand Guidelines — SampahKita

## 1. Arah identitas
**Konsep logo:** Home & Bank — rumah, pilar bank, dan daun.
**Makna:** lingkungan, organisasi, pelayanan masyarakat, dan pengelolaan bank sampah.
**Karakter:** ramah, tepercaya, bersih, praktis, berorientasi keberlanjutan.
**Descriptor:** BANK SAMPAH DIGITAL.

## 2. Palet warna
| Nama | HEX | Penggunaan |
|---|---|---|
| Forest Green | `#14532D` | Warna primer, navigasi aktif, tombol utama |
| Leaf Green | `#65A30D` | Aksen, ikon, indikator positif |
| Lime Green | `#A3E635` | Highlight kecil; gunakan secukupnya |
| Mint | `#E8F5E9` | Latar lembut dan permukaan sekunder |
| White | `#FFFFFF` | Latar utama |
| Ink | `#17231B` | Teks utama |
| Muted Green Gray | `#64756A` | Teks sekunder |
| Soft Border | `#DCE8DE` | Border dan divider |

## 3. Tipografi
Gunakan **Inter** jika tersedia; fallback `Arial, sans-serif`.
- Heading: weight 600–800
- Body: weight 400–500
- Label/metadata: weight 400–500
- Utamakan keterbacaan dan ruang antarelemen.

## 4. Penggunaan UI
- Tombol primer: Forest Green dengan teks putih.
- Latar kartu sekunder: Mint.
- Border: Soft Border.
- Radius: 8 px (kecil), 14 px (standar), 20 px (besar).
- Bayangan kartu lembut; tabel transaksi harus mudah dipindai.
- Jangan mengandalkan warna saja untuk status; tambahkan label/ikon.

## 5. Penggunaan logo
- `sampahkita_horizontal.svg`: header/sidebar.
- `sampahkita_symbol.svg`: simbol saja untuk ruang terbatas.
- `sampahkita_horizontal_white.svg`: latar gelap/hijau tua.
- `favicon.svg` atau `app-icon.svg`: ikon aplikasi.
- Jangan meregangkan logo atau mengubah proporsi. Pastikan kontras memadai.

## 6. Aksesibilitas
Lime Green adalah aksen, bukan pilihan utama untuk teks kecil di atas putih. Beri label jelas pada tombol, input, dan status.
